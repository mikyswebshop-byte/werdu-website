<?php
/**
 * Template Name: WERDU Partner werden
 * Description: B2B Landing — Montage-Partner & Fachhändler-Netzwerk mit Major-City IP-Geo
 *
 * @package Shoppingcart_Child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="werdu-partner" itemscope itemtype="https://schema.org/WebPage">
	<header class="wp-hero">
		<div class="wp-wrap">
			<div class="wp-badge">Offenes Partnernetzwerk · Deutschlandweit</div>
			<h1 itemprop="headline">Partner werden bei WERDU.de</h1>
			<p class="wp-hero-lead" itemprop="description">
				Werden Sie Montage-Partner oder Fachpartner &amp; Händler für transparente LiFePO4-Heimspeicher:
				klare Konditionen, regionale Aufträge und ein Netzwerk, das Elektriker und Fachhändler in Deutschland stärkt — ohne undurchsichtige Projektpreise.
			</p>
			<div class="wp-hero-cta">
				<a class="wp-btn wp-btn-primary" href="#partner-anfrage">Jetzt Partnerschaft anfragen</a>
				<a class="wp-btn wp-btn-secondary" href="<?php echo esc_url( home_url( '/shop/' ) ); ?>">Shop &amp; Preise ansehen</a>
			</div>
		</div>
	</header>

	<div class="wp-wrap">
		<section class="wp-cards" aria-label="Partner-Modelle">
			<article class="wp-card wp-card--montage" data-wp-select-type="montage" tabindex="0" role="button" aria-label="Montage-Partner auswählen">
				<span class="wp-card-tag">Installation vor Ort</span>
				<h2>Montage-Partner</h2>
				<p class="wp-card-price">300 € – 500 € pro Anschluss</p>
				<p>
					Als zertifizierter Installateur übernehmen Sie die fachgerechte Montage beim Endkunden —
					inkl. DC-Anbindung und Datenkabel (CAN/RS485). Lieferung kann direkt an Ihren Betrieb erfolgen.
				</p>
				<ul class="wp-list">
					<li>Regionale Aufträge im gewünschten Radius</li>
					<li>Technische Support-Linie &amp; Montageleitfäden</li>
					<li>Transparente Produktpreise für Ihre Kundenberatung</li>
					<li>Richtwert 300 € – 500 € Montageaufwand direkt mit dem Endkunden</li>
				</ul>
			</article>

			<article class="wp-card wp-card--b2b" data-wp-select-type="b2b" tabindex="0" role="button" aria-label="Fachpartner &amp; Händler auswählen">
				<span class="wp-card-tag">Handel &amp; Wiederverkauf</span>
				<h2>Fachpartner &amp; Händler</h2>
				<p class="wp-card-price">B2B-Einkauf ab 3 Einheiten</p>
				<p>
					Als Fachhändler oder Systemintegrator beziehen Sie WERDU-Heimspeicher zu Partnerkonditionen
					und verkaufen sie mit eigenen Services an Ihre Kundschaft weiter.
				</p>
				<ul class="wp-list">
					<li>Händlerkonditionen ab 3 Einheiten</li>
					<li>Schnelle Verfügbarkeit &amp; Direktversand</li>
					<li>Marketing-Material &amp; Produkt-Datenblätter</li>
					<li>Direkter Ansprechpartner im Partner-Support</li>
				</ul>
			</article>
		</section>

		<section class="wp-form-section" id="partner-anfrage" aria-labelledby="partner-form-title">
			<h2 id="partner-form-title">Partnerschaft anfragen</h2>
			<p class="wp-form-intro">
				Kurz ausfüllen — wir prüfen Verfügbarkeit und Konditionen in Ihrer Region und melden uns zeitnah.
			</p>

			<div class="wp-geo" data-wp-geo aria-hidden="true" role="status">
				<span class="wp-geo-icon" aria-hidden="true">PLZ</span>
				<div>
					Verfügbarkeit prüfen für PLZ-Bereich
					<span data-wp-plz>—</span>
					(<span data-wp-city>—</span> &amp; Großraum)
				</div>
			</div>

			<?php
			if ( function_exists( 'werdu_partner_render_form' ) ) {
				werdu_partner_render_form();
			}
			?>
		</section>

		<section class="wp-process" aria-labelledby="partner-process-title">
			<h2 id="partner-process-title">So funktioniert die Partnerschaft</h2>
			<div class="wp-steps">
				<div class="wp-step">
					<div class="wp-step-num">1</div>
					<h3>Anfrage senden</h3>
					<p>Firma, PLZ und gewünschter Partnerschafts-Typ — in unter zwei Minuten erledigt.</p>
				</div>
				<div class="wp-step">
					<div class="wp-step-num">2</div>
					<h3>Region &amp; Kapazität prüfen</h3>
					<p>Wir prüfen Abdeckung, Radius und passende Auftragsarten in Ihrem Einsatzgebiet.</p>
				</div>
				<div class="wp-step">
					<div class="wp-step-num">3</div>
					<h3>Freischaltung &amp; Start</h3>
					<p>Onboarding mit Konditionen, Support und — bei Montage — regionaler Auftragszuweisung.</p>
				</div>
			</div>
		</section>

		<p class="wp-footnote">
			WERDU.de · LiFePO4-Heimspeicher mit transparenten Preisen ·
			<a href="<?php echo esc_url( home_url( '/kontakt/' ) ); ?>">Kontakt</a> ·
			<a href="<?php echo esc_url( home_url( '/datenschutzerklaerung/' ) ); ?>">Datenschutz</a>
		</p>
	</div>
</main>

<?php
get_footer();
