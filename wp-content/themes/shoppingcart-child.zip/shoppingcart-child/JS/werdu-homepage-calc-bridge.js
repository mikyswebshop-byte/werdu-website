/**
 * Homepage Calc 2 bridge — wraps Elementor werduCalc()
 * Builds enriched werdu_calc_result + Beratung CTA with clean query params.
 */
(function () {
  'use strict';

  var MONTH_FACTORS = [0.03, 0.05, 0.09, 0.13, 0.15, 0.15, 0.15, 0.13, 0.10, 0.07, 0.04, 0.02];
  var MONTH_NAMES = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
  var bridged = false;

  function recommendKwh(verbrauch, planEl) {
    var kwh = verbrauch <= 4500 ? 16 : (verbrauch <= 7000 ? 16 : 32);
    if (planEl) {
      var opt = planEl.options[planEl.selectedIndex];
      var label = ((opt && opt.text) ? opt.text : '') + ' ' + planEl.value;
      if (/30|32/.test(label)) kwh = 32;
      else if (/\b15\b/.test(label)) kwh = 15;
      else if (/\b16\b/.test(label)) kwh = 16;
      else if (/\b10\b/.test(label)) kwh = 10;
    }
    return kwh;
  }

  function buildMonthly(annualYield, usage, autarky) {
    var monthlyCons = usage / 12;
    return MONTH_FACTORS.map(function (factor, idx) {
      var gen = Math.round(annualYield * factor);
      var cons = Math.round(monthlyCons);
      var stored = Math.round(Math.min(cons * (autarky / 100), gen * 0.55));
      return { month: MONTH_NAMES[idx], generation: gen, consumption: cons, battery: stored };
    });
  }

  function buildBeratungUrl(data) {
    return 'https://werdu.de/beratung-anfragen/?' +
      'kwh=' + encodeURIComponent(data.kwh) +
      '&peak=' + encodeURIComponent(data.peak) +
      '&savings=' + encodeURIComponent(data.savings) +
      '&plz=' + encodeURIComponent(data.plz) +
      '&goal=' + encodeURIComponent(data.goal) +
      '&usage=' + encodeURIComponent(data.usage) +
      '&autarky=' + encodeURIComponent(data.autarky) +
      '&self=' + encodeURIComponent(data.selfConsumption);
  }

  function persistAndLink(data) {
    try {
      sessionStorage.setItem('werdu_calc_result', JSON.stringify(data));
    } catch (e) {}

    var url = buildBeratungUrl(data);
    document.querySelectorAll('a.werdu-calc-cta, a[href*="beratung-anfragen"]').forEach(function (a) {
      // Only rewrite homepage calc CTAs / plain beratung links in calc section
      var inCalc = a.closest('#solarbatterie-rechner, .werdu-calc-section, .werdu-calc-result, #calc-result');
      if (inCalc || a.classList.contains('werdu-calc-cta')) {
        a.href = url;
      }
    });

    // Inject CTA under result if missing
    var resultEl = document.getElementById('calc-result') || document.getElementById('calc_result');
    if (resultEl && !resultEl.querySelector('.werdu-calc-cta-bridge')) {
      var link = document.createElement('a');
      link.className = 'werdu-calc-cta werdu-calc-cta-bridge';
      link.href = url;
      link.textContent = 'Kostenlose Fachanalyse mit diesen Werten anfordern →';
      link.style.cssText = 'display:inline-block;margin-top:16px;background:#FF6600;color:#fff;font-weight:800;padding:14px 22px;border-radius:12px;text-decoration:none;';
      resultEl.appendChild(link);
    }
  }

  function captureAfterCalc() {
    var plzEl = document.getElementById('calc_location');
    var pvEl = document.getElementById('calc_pv_leistung');
    var verbrauchEl = document.getElementById('calc_verbrauch');
    var dachEl = document.getElementById('calc_dachneigung');
    var ausrEl = document.getElementById('calc_ausrichtung');
    var planEl = document.getElementById('calc_plan');

    if (!plzEl || !pvEl || !verbrauchEl) return;

    var plz = String(plzEl.value || '').replace(/\D/g, '').substring(0, 5);
    var pv = parseFloat(pvEl.value) || 0;
    var verbrauch = parseFloat(verbrauchEl.value) || 0;
    if (!pv || !verbrauch) return;

    var dach = parseFloat(dachEl ? dachEl.value : 1) || 1;
    var ausrichtung = parseFloat(ausrEl ? ausrEl.value : 1) || 1;
    var ertrag = Math.round(pv * 950 * dach * ausrichtung);
    var ersparnis = Math.round(ertrag * 0.35 * 0.35);
    var autarkie = Math.min(Math.round((ertrag / verbrauch) * 100), 95);
    var selfConsumption = Math.min(95, Math.round((verbrauch / Math.max(ertrag, 1)) * 100 * 1.2));
    if (ertrag < verbrauch) {
      selfConsumption = Math.min(95, Math.round((ertrag / verbrauch) * 100 * 1.2));
    }
    var kwh = recommendKwh(verbrauch, planEl);

    var data = {
      kwh: String(kwh),
      peak: String(pv),
      savings: String(ersparnis),
      plz: plz,
      goal: 'year',
      usage: String(Math.round(verbrauch)),
      autarky: String(autarkie),
      selfConsumption: String(selfConsumption),
      annualYield: String(ertrag),
      monthly: buildMonthly(ertrag, verbrauch, autarkie),
      source: 'homepage-calc-2',
      version: 2
    };

    persistAndLink(data);
  }

  function wrapWerduCalc() {
    if (typeof window.werduCalc !== 'function') return false;
    if (window.werduCalc.__werduBridged) {
      bridged = true;
      return true;
    }

    var original = window.werduCalc;
    window.werduCalc = function () {
      var result = original.apply(this, arguments);
      // Defer so Elementor DOM result updates first
      setTimeout(captureAfterCalc, 0);
      return result;
    };
    window.werduCalc.__werduBridged = true;
    bridged = true;
    return true;
  }

  function bindButtonFallback() {
    document.querySelectorAll('button.werdu-calc-btn, #calc-submit').forEach(function (btn) {
      if (btn.dataset.werduBridge === '1') return;
      btn.dataset.werduBridge = '1';
      btn.addEventListener('click', function () {
        setTimeout(captureAfterCalc, 50);
      });
    });

    var form = document.getElementById('pv-calculator');
    if (form && form.dataset.werduBridge !== '1') {
      form.dataset.werduBridge = '1';
      form.addEventListener('submit', function () {
        setTimeout(captureAfterCalc, 50);
      });
    }
  }

  function tryBridge() {
    wrapWerduCalc();
    bindButtonFallback();
    return bridged;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryBridge);
  } else {
    tryBridge();
  }
  window.addEventListener('load', tryBridge);

  // Elementor may inject scripts late
  var attempts = 0;
  var timer = setInterval(function () {
    attempts += 1;
    if (tryBridge() || attempts > 40) clearInterval(timer);
  }, 250);
})();
